# build_live_stats.py
# Render Liberty League pages with Playwright (JS-enabled) and output JSON files consumed by index.html

import asyncio
import json
from datetime import datetime, timezone

import pandas as pd
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright

CONF_URL = 'https://libertyleagueathletics.com/stats.aspx?path=baseball&year=2026'


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def df_to_rows(df):
    out = []
    for _, row in df.iterrows():
        rec = {}
        for c in df.columns:
            v = row[c]
            if pd.isna(v):
                rec[str(c)] = None
            else:
                if isinstance(v, (pd.Timestamp,)):
                    rec[str(c)] = str(v)
                else:
                    rec[str(c)] = v.item() if hasattr(v, 'item') else v
        out.append(rec)
    return out


def parse_first_table(html):
    dfs = pd.read_html(html)
    if len(dfs) == 0:
        return pd.DataFrame()
    return dfs[0]


def extract_team_links(conf_html):
    s = BeautifulSoup(conf_html, 'html.parser')
    links = []
    for a in s.select('a[href*="teamstats.aspx"][href*="path=baseball"][href*="year=2026"]'):
        team = a.get_text(' ', strip=True)
        href = a.get('href')
        if not href:
            continue
        url = href if href.startswith('http') else 'https://libertyleagueathletics.com/' + href.lstrip('/')
        if team:
            links.append((team, url))
    seen = set()
    out = []
    for team, url in links:
        if (team, url) in seen:
            continue
        seen.add((team, url))
        out.append({'team': team, 'team_url': url})
    return out


def find_tables(page_html):
    s = BeautifulSoup(page_html, 'html.parser')
    return s.select('table.sidearm-table')


def table_to_df(table_tag):
    return parse_first_table(str(table_tag))


def normalize_player_df(df, team_name, stat_type):
    df2 = df.copy()
    if 'Player' in df2.columns:
        df2 = df2[df2['Player'].notna()]
        df2['Player'] = df2['Player'].astype(str).str.strip()
        df2 = df2[df2['Player'].str.len() > 0]
    df2.columns = [str(c).strip() for c in df2.columns]
    df2['team'] = team_name
    df2['stat_type'] = stat_type
    df2 = df2.rename(columns={'Player': 'player_name'})
    # derived OPS if present
    if 'OB%' in df2.columns and 'SLG%' in df2.columns:
        obp = pd.to_numeric(df2['OB%'], errors='coerce')
        slg = pd.to_numeric(df2['SLG%'], errors='coerce')
        df2['OPS'] = obp + slg
    return df2


def pick_hitting_pitching_tables(tables):
    # Heuristic: choose the two widest tables as hitting and pitching (SIDEARM usually renders 2-3 stat tables)
    dfs = []
    for t in tables:
        try:
            df = table_to_df(t)
            if df.shape[0] == 0:
                continue
            dfs.append(df)
        except Exception:
            continue
    if len(dfs) == 0:
        return None, None
    dfs_sorted = sorted(dfs, key=lambda d: d.shape[1], reverse=True)
    hit = dfs_sorted[0]
    pit = dfs_sorted[1] if len(dfs_sorted) > 1 else None
    return hit, pit


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        # Conference page (team-level)
        await page.goto(CONF_URL, wait_until='networkidle', timeout=120000)
        conf_html = await page.content()

        # Grab the first visible stats table for team batting and keep the columns as-is
        team_table_tags = find_tables(conf_html)
        team_df = pd.DataFrame()
        if len(team_table_tags) > 0:
            team_df = table_to_df(team_table_tags[0])

        # Attach team URLs for drilldowns when possible
        team_links = extract_team_links(conf_html)
        if 'Team' in team_df.columns:
            url_map = {d['team']: d['team_url'] for d in team_links}
            team_df['Team URL'] = team_df['Team'].map(url_map)

        # Derived team OPS if OB% and SLG% exist
        if 'OB%' in team_df.columns and 'SLG%' in team_df.columns:
            team_df['OPS'] = pd.to_numeric(team_df['OB%'], errors='coerce') + pd.to_numeric(team_df['SLG%'], errors='coerce')

        team_payload = {'generated_at': now_iso(), 'rows': df_to_rows(team_df)}
        with open('live_team_stats.json', 'w', encoding='utf-8') as f:
            json.dump(team_payload, f)

        # Player-level: iterate each team stats page and render JS
        player_frames = []
        for tl in team_links:
            team_name = tl['team']
            team_url = tl['team_url']
            try:
                await page.goto(team_url, wait_until='networkidle', timeout=120000)
                team_html = await page.content()
                tables = find_tables(team_html)
                hit_df, pit_df = pick_hitting_pitching_tables(tables)

                if hit_df is not None and hit_df.shape[0] > 0:
                    player_frames.append(normalize_player_df(hit_df, team_name, 'hitting'))
                if pit_df is not None and pit_df.shape[0] > 0:
                    player_frames.append(normalize_player_df(pit_df, team_name, 'pitching'))
            except Exception:
                continue

        players_df = pd.concat(player_frames, ignore_index=True) if len(player_frames) > 0 else pd.DataFrame(columns=['player_name','team','stat_type'])
        players_payload = {'generated_at': now_iso(), 'rows': df_to_rows(players_df)}
        with open('live_players.json', 'w', encoding='utf-8') as f:
            json.dump(players_payload, f)

        await browser.close()


if __name__ == '__main__':
    asyncio.run(main())
